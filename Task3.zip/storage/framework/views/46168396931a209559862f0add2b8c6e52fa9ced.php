<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<?php if(session()->has('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
 

<?php if(session()->has('info')): ?>
<div class="alert alert-info">
    <?php echo e(session('info')); ?>

</div>
<?php endif; ?>


<?php if(session()->has('warning')): ?>
<div class="alert alert-warning">
    <?php echo e(session('warning')); ?>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Almansy_Laravel3\Task3\resources\views/components/flash-message.blade.php ENDPATH**/ ?>