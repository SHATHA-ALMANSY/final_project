

<?php $__env->startSection('title','Edit Category'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('dashboard.categories.update' , $category->id )); ?>" method="post">
    <?php echo method_field('put'); ?>
    <?php echo $__env->make('dashboard.categories._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
</form>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Almansy_Laravel3\Task3\resources\views/dashboard/categories/edit.blade.php ENDPATH**/ ?>