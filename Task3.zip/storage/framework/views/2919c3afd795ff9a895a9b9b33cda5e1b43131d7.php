<div class="alert alert-<?php echo e($type); ?>">
    <!-- Test Message ! -->
    <!-- <?php echo e($slot); ?> -->

    <?php if( (string) $slot ): ?>
    <?php echo e($slot); ?>

    <?php else: ?> 
    Defult Message 
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\Almansy_Laravel3\Task3\resources\views/components/alert.blade.php ENDPATH**/ ?>